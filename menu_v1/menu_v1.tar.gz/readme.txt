This is a menu program!

Build Procedure
    $ gcc main.c menu.c linktable.c -o menu
    $ ./menu 
# you can input one to nine & exit cmd.
