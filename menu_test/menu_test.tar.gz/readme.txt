This is a menu program!

Build Procedure
    $ make
    $ ./menu 
# you can input one to nine & exit cmd.
