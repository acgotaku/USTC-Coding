This is a menu program!

Build Procedure
    $ gcc test.c menu.c linktable.c -o menu
    $ ./menu 
# you can input one to nine & exit cmd.
